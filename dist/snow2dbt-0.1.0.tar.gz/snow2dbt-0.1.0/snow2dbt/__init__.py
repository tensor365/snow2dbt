from .snow2dbt import snow2dbt

def main():
    snow2dbt()